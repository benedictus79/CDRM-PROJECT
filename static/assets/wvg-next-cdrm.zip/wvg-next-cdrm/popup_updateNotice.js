document.addEventListener('DOMContentLoaded', async function() {
    let currentVersion = '1.0'; // Replace '1.0' with your current extension version

    // Prepare the JSON data to send in the POST request
    let postData = {
        'version': currentVersion
    };

    // Set request options
    let requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData)
    };

    // Send post request to check for updates
    fetch('http://127.0.0.1:5000/download-extension', requestOptions)
        .then(response => {
            return response.json()
                .then(data => {
                    // Check if the response version matches the current version
                    if (data['Version'] && data['Version'] !== currentVersion) {
                        let notice = document.getElementById("updateNotice");
                        notice.style.display = 'grid'
                        notice.style.gridTemplateRows = 'auto'
                        notice.innerHTML = `An update to version ${data['Version']} is available. <a href="https://cdrm-project.com/download-extension">Download</a>`;
                    }
                });
        })
        .catch(error => {
            console.error('Error checking for updates:', error);
        });
});